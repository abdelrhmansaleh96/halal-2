export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
    "postcss-rtlcss": {},
  },
};
