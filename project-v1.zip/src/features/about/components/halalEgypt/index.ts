export * from "./halalEgypt.about";
