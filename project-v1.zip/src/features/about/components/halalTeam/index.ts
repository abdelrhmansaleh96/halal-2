export * from "./halalTeam.about";
