export * from "./whatHalal.about";
