export * from "./descriptionText.about";
