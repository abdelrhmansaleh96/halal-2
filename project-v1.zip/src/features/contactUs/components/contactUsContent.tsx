import { ContactFormContainer } from "./ContactFormContainer";

export const ContactUsContent: React.FC = () => {
  return (
    <div className="flex flex-col">
      <ContactFormContainer />
    </div>
  );
};
