import App from "../App";

function AppInitializer() {
  // const isPreference = usePreference("all", []);

  // if (!isPreference.isTimeoutComplete) {
  //   return (
  //     <section className={styles.init}>
  //       <h2 className={styles.init__msg}>{isPreference.message}</h2>
  //     </section>
  //   );
  // }
  return <App />;
}

export default AppInitializer;
