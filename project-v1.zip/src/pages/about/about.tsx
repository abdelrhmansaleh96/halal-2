import { AboutHOC } from "@/hoc";

export const About: React.FC = () => {
  return <AboutHOC />;
};
