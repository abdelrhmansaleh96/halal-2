import { ContactUsContent } from "@/features/contactUs";

export const ContactUs: React.FC = () => {
  return <ContactUsContent />;
};
