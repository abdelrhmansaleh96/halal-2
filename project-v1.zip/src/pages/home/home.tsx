import { HomeContent } from "@/features";

export const Home: React.FC = () => {
  return <HomeContent />;
};
