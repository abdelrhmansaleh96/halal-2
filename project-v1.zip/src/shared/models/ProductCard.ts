export type TProductCard = {
  img: string; // as background for the card
  title: string;
};
