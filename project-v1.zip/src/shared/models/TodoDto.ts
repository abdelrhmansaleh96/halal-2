export interface TodoDto {
  checked?: boolean;
  title?: string;
  description?: string;
  id: number;
}
